const CACHE_NAME = 'cc-losmochis-v47';
const ASSETS = [
  '/',
  '/index.html',
  '/css/style.css',
  '/css/auth_style.css',
  '/js/engine.js',
  '/js/auth.js',
  '/LOGOCOUNTRY.png',
  '/manifest.json'
];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE_NAME).then(c => c.addAll(ASSETS)));
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys =>
    Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
  ));
  self.clients.claim();
});

self.addEventListener('fetch', e => {
  e.respondWith(
    fetch(e.request).catch(() => caches.match(e.request))
  );
});
